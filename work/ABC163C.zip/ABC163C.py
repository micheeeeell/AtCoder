N = int(input())

A = []

for i in range(N-1):
    A.append(int(input()))

B = []

for j in range(N-1):
    temp = 0
    for i in A:
        if i-2 == j:
            temp += 1
    B.append(temp)        
for j in range(N-1):
    print(B[j])